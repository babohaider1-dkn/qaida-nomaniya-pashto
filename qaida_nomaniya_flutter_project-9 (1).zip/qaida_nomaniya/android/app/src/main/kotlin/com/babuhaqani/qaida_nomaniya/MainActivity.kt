package com.babuhaqani.qaida_nomaniya

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
