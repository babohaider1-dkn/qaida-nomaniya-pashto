Place these font files in this folder:
- NotoNastaliqUrdu-Regular.ttf
- NotoNastaliqUrdu-Bold.ttf

Download from: https://fonts.google.com/noto/specimen/Noto+Nastaliq+Urdu
