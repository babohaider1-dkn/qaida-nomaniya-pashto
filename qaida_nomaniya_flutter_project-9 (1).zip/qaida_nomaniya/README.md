# قاعدہ نعمانیہ پشتو — Flutter App
## مصنف: Babu Haider Haqqani

---

## STEP-BY-STEP APK BUILD GUIDE

### Prerequisites (One-time Setup)

1. **Install Flutter SDK** (v3.16+)
   - Download: https://docs.flutter.dev/get-started/install
   - Extract to `C:\flutter` (Windows) or `~/flutter` (Mac/Linux)
   - Add `flutter/bin` to your PATH

2. **Install Android Studio**
   - Download: https://developer.android.com/studio
   - During setup, install Android SDK (API 33+)
   - Accept licenses: `flutter doctor --android-licenses`

3. **Verify Setup**
   ```
   flutter doctor
   ```
   All items should show ✓ (green checkmarks)

---

### Project Setup

1. **Extract this project** to a folder, e.g. `C:\qaida_nomaniya\`

2. **Download Noto Nastaliq Urdu Font**
   - Go to: https://fonts.google.com/noto/specimen/Noto+Nastaliq+Urdu
   - Download and extract
   - Copy these files to `assets/fonts/`:
     - `NotoNastaliqUrdu-Regular.ttf`
     - `NotoNastaliqUrdu-Bold.ttf`

3. **Add your Audio Files**
   - Put ALL your MP3 files into `assets/audio/` folder:
     ```
     assets/audio/takhta01.mp3
     assets/audio/takhta02.mp3
     assets/audio/takhta03.mp3
     assets/audio/takhta04.mp3
     assets/audio/takhta05.mp3
     assets/audio/takhta06.mp3
     assets/audio/takhta07.mp3
     assets/audio/takhta08.mp3
     assets/audio/takhta09.mp3
     assets/audio/takhta10.mp3
     assets/audio/takhta11.mp3
     assets/audio/takhta12.mp3
     assets/audio/takhta13.mp3
     assets/audio/takhta14.mp3
     assets/audio/takhta15.mp3
     assets/audio/takhta16.mp3
     assets/audio/takhta17.mp3
     assets/audio/takhta18.mp3
     assets/audio/takhta19.mp3
     assets/audio/takhta20.mp3
     assets/audio/takhta21.mp3
     assets/audio/takhta22.mp3
     assets/audio/takhta23.mp3
     assets/audio/takhta24.mp3
     assets/audio/takhta25.mp3
     assets/audio/takhta26.mp3
     assets/audio/takhta27.mp3
     assets/audio/takhta28.mp3
     assets/audio/takhta29.mp3
     assets/audio/takhta30.mp3
     assets/audio/takhta31.mp3
     assets/audio/namaz.mp3
     assets/audio/dua.mp3
     ```

4. **Open Terminal / Command Prompt** in the project folder

5. **Install dependencies**
   ```
   flutter pub get
   ```

---

### Build the APK

**Option A — Debug APK (for testing)**
```
flutter build apk --debug
```
APK location: `build/app/outputs/flutter-apk/app-debug.apk`

**Option B — Release APK (for distribution)**
```
flutter build apk --release
```
APK location: `build/app/outputs/flutter-apk/app-release.apk`

**Option C — Split APKs by architecture (smaller size)**
```
flutter build apk --split-per-abi --release
```
This creates 3 smaller APKs for different phone types.

---

### Install on Your Phone

**Method 1 — USB Cable**
```
flutter install
```

**Method 2 — ADB**
```
adb install build/app/outputs/flutter-apk/app-release.apk
```

**Method 3 — Transfer the APK file** to your phone and install it directly
(Enable "Install from Unknown Sources" in phone settings first)

---

### App Icon (Optional)

To add a custom app icon:
1. Install package: add `flutter_launcher_icons: ^0.13.1` to `dev_dependencies` in pubspec.yaml
2. Add your icon image as `assets/icon.png` (1024×1024 px)
3. Add to pubspec.yaml:
   ```yaml
   flutter_launcher_icons:
     android: true
     image_path: "assets/icon.png"
   ```
4. Run: `flutter pub run flutter_launcher_icons`

---

### Troubleshooting

**"Gradle build failed"**
- Run: `flutter clean && flutter pub get && flutter build apk`

**"Audio not playing"**
- Make sure MP3 files are placed in `assets/audio/` folder
- File names must match exactly (case-sensitive): `takhta01.mp3`
- Run `flutter pub get` after adding files

**"Font not showing correctly"**
- Make sure font .ttf files are in `assets/fonts/`
- Exact filenames: `NotoNastaliqUrdu-Regular.ttf` and `NotoNastaliqUrdu-Bold.ttf`

**"Build taking too long"**
- First build always takes 5-15 minutes (downloading Gradle)
- Subsequent builds are faster (2-3 minutes)

---

### Project Structure

```
qaida_nomaniya/
├── lib/
│   └── main.dart           ← Complete app code
├── assets/
│   ├── audio/              ← Put your MP3 files here
│   │   ├── takhta01.mp3
│   │   ├── takhta02.mp3
│   │   └── ... (33 total)
│   └── fonts/              ← Put Noto Nastaliq Urdu fonts here
│       ├── NotoNastaliqUrdu-Regular.ttf
│       └── NotoNastaliqUrdu-Bold.ttf
├── android/                ← Android config (don't modify)
└── pubspec.yaml            ← Dependencies config
```

---

### Contact & Support
WhatsApp: ________________
