import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const QaidaNomaniyaApp());
}

class QaidaNomaniyaApp extends StatelessWidget {
  const QaidaNomaniyaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'قاعدہ نعمانیہ پشتو',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0A3D0A),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF0A3D0A),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

// ─────────────────────────────────────────────
// Data model
// ─────────────────────────────────────────────
class TakhtaItem {
  final String title;
  final String subtitle;
  final String audioFile;
  final String lessonText;

  const TakhtaItem({
    required this.title,
    required this.subtitle,
    required this.audioFile,
    required this.lessonText,
  });
}

const List<TakhtaItem> takhtaList = [
  TakhtaItem(
    title: 'پہلی تختہ',
    subtitle: 'حروف تہجی کا سبق',
    audioFile: 'takhta01.mp3',
    lessonText: 'ا ب پ ت ٹ ث ج چ ح خ د ڈ ذ ر ڑ ز ژ س ش ص ض ط ظ ع غ ف ق ک گ ل م ن و ہ ء ی',
  ),
  TakhtaItem(
    title: 'دوسری تختہ',
    subtitle: 'مرکبات کا سبق',
    audioFile: 'takhta02.mp3',
    lessonText: 'بَ بِ بُ بَا بِی بُو',
  ),
  TakhtaItem(
    title: 'تیسری تختہ',
    subtitle: 'زبر کا سبق',
    audioFile: 'takhta03.mp3',
    lessonText: 'بَ تَ ثَ جَ حَ خَ دَ ذَ رَ زَ سَ شَ',
  ),
  TakhtaItem(
    title: 'چوتھی تختہ',
    subtitle: 'زیر کا سبق',
    audioFile: 'takhta04.mp3',
    lessonText: 'بِ تِ ثِ جِ حِ خِ دِ ذِ رِ زِ سِ شِ',
  ),
  TakhtaItem(
    title: 'پانچویں تختہ',
    subtitle: 'پیش کا سبق',
    audioFile: 'takhta05.mp3',
    lessonText: 'بُ تُ ثُ جُ حُ خُ دُ ذُ رُ زُ سُ شُ',
  ),
  TakhtaItem(
    title: 'چھٹی تختہ',
    subtitle: 'دو زبر کا سبق',
    audioFile: 'takhta06.mp3',
    lessonText: 'بً تً ثً جً حً خً دً ذً رً زً سً شً',
  ),
  TakhtaItem(
    title: 'ساتویں تختہ',
    subtitle: 'دو زیر کا سبق',
    audioFile: 'takhta07.mp3',
    lessonText: 'بٍ تٍ ثٍ جٍ حٍ خٍ دٍ ذٍ رٍ زٍ سٍ شٍ',
  ),
  TakhtaItem(
    title: 'آٹھویں تختہ',
    subtitle: 'دو پیش کا سبق',
    audioFile: 'takhta08.mp3',
    lessonText: 'بٌ تٌ ثٌ جٌ حٌ خٌ دٌ ذٌ رٌ زٌ سٌ شٌ',
  ),
  TakhtaItem(
    title: 'نویں تختہ',
    subtitle: 'جزاک یا سُکون کا سبق',
    audioFile: 'takhta09.mp3',
    lessonText: 'بْ تْ ثْ جْ حْ خْ دْ ذْ رْ زْ سْ شْ',
  ),
  TakhtaItem(
    title: 'دسویں تختہ',
    subtitle: 'قلقلہ کا سبق',
    audioFile: 'takhta10.mp3',
    lessonText: 'قْ طْ بْ جْ دْ',
  ),
  TakhtaItem(
    title: 'گیارہویں تختہ',
    subtitle: 'کھڑی زبر کا سبق',
    audioFile: 'takhta11.mp3',
    lessonText: 'بٰ تٰ ثٰ جٰ حٰ خٰ دٰ ذٰ رٰ',
  ),
  TakhtaItem(
    title: 'بارہویں تختہ',
    subtitle: 'کھڑی زیر کا سبق',
    audioFile: 'takhta12.mp3',
    lessonText: 'بٖ تٖ ثٖ جٖ حٖ خٖ دٖ ذٖ رٖ',
  ),
  TakhtaItem(
    title: 'چودہویں تختہ',
    subtitle: 'الٹا پیش کا سبق',
    audioFile: 'takhta13.mp3',
    lessonText: 'بٗ تٗ ثٗ جٗ حٗ خٗ دٗ ذٗ رٗ',
  ),
  TakhtaItem(
    title: 'پندرہویں تختہ',
    subtitle: 'الف مدہ کا سبق',
    audioFile: 'takhta14.mp3',
    lessonText: 'آ مَآء قُرآن کِتَاب',
  ),
  TakhtaItem(
    title: 'سولہویں تختہ',
    subtitle: 'واو مدہ کا سبق',
    audioFile: 'takhta15.mp3',
    lessonText: 'نُوح لُوط دَاوُود',
  ),
  TakhtaItem(
    title: 'سترہویں تختہ',
    subtitle: 'جایے مدہ کا سبق',
    audioFile: 'takhta16.mp3',
    lessonText: 'فِي الدِّينِ قِيلَ',
  ),
  TakhtaItem(
    title: 'اٹھارہویں تختہ',
    subtitle: 'واو لین کا سبق',
    audioFile: 'takhta17.mp3',
    lessonText: 'خَوْف قَوْل',
  ),
  TakhtaItem(
    title: 'انیسویں تختہ',
    subtitle: 'جایے لین کا سبق',
    audioFile: 'takhta18.mp3',
    lessonText: 'بَيْت عَيْن',
  ),
  TakhtaItem(
    title: 'بیسویں تختہ',
    subtitle: 'شد کا سبق',
    audioFile: 'takhta19.mp3',
    lessonText: 'إِنَّ ثُمَّ رَبَّ',
  ),
  TakhtaItem(
    title: 'اکیسویں تختہ',
    subtitle: 'مد کے اقسام قاعدے سبق اور مشق',
    audioFile: 'takhta20.mp3',
    lessonText: 'مَدّ لَازِم مَدّ مُتَّصِل مَدّ مُنْفَصِل',
  ),
  TakhtaItem(
    title: 'اکیسویں تختہ',
    subtitle: 'ر پر پڑھنے کے قاعدے اور سبق',
    audioFile: 'takhta21.mp3',
    lessonText: 'رَب رَحِيم رَحْمَن',
  ),
  TakhtaItem(
    title: 'بائیسویں تختہ',
    subtitle: 'را باریک پڑھنے کے قاعدے اور سبق',
    audioFile: 'takhta22.mp3',
    lessonText: 'رِزق رِجَال',
  ),
  TakhtaItem(
    title: 'تئیسویں تختہ',
    subtitle: 'لفظ اللہ پر اور باریک پڑھنے کے قاعدے اور سبق',
    audioFile: 'takhta23.mp3',
    lessonText: 'اللَّه بِسْمِ اللَّه',
  ),
  TakhtaItem(
    title: 'چوبیسویں تختہ',
    subtitle: 'اظہار کرنے قاعدہ اور سبق',
    audioFile: 'takhta24.mp3',
    lessonText: 'مِنْ حَيْث مِنْ خَوْف',
  ),
  TakhtaItem(
    title: 'پچیسویں تختہ',
    subtitle: 'ادغام کا قاعدہ اور سبق',
    audioFile: 'takhta25.mp3',
    lessonText: 'مِن رَّبِّ مِن وَّلِيٍّ',
  ),
  TakhtaItem(
    title: 'چھبیسویں تختہ',
    subtitle: 'انقلاب کا قاعدہ اور سبق',
    audioFile: 'takhta26.mp3',
    lessonText: 'أَنبِيَاء عَنبَر',
  ),
  TakhtaItem(
    title: 'ستائیسویں تختہ',
    subtitle: 'اخفاء کا قاعدہ اور سبق',
    audioFile: 'takhta27.mp3',
    lessonText: 'مِن تَحْت مَن تَاب',
  ),
  TakhtaItem(
    title: 'اٹھائیسویں تختہ',
    subtitle: 'حروف یرملو کا قاعدہ اور سبق',
    audioFile: 'takhta28.mp3',
    lessonText: 'ی ر م ل و ن',
  ),
  TakhtaItem(
    title: 'انتیسویں تختہ',
    subtitle: 'نون قطنی کا قاعدہ اور سبق',
    audioFile: 'takhta29.mp3',
    lessonText: 'نٓ وَالْقَلَمِ',
  ),
  TakhtaItem(
    title: 'تیسویں تختہ',
    subtitle: 'حروف مقطعات قاعدہ اور سبق',
    audioFile: 'takhta30.mp3',
    lessonText: 'الٓمٓ الٓرٰ الٓمٓرٰ',
  ),
  TakhtaItem(
    title: 'اکتیسویں تختہ',
    subtitle: 'غنہ کے قاعدے اور سبق',
    audioFile: 'takhta31.mp3',
    lessonText: 'إِنَّ أَنَّ كَأَنَّ',
  ),
  TakhtaItem(
    title: 'مکمل نماز',
    subtitle: 'نماز کا سبق',
    audioFile: 'namaz.mp3',
    lessonText: 'سُبْحَانَكَ اللَّهُمَّ وَبِحَمْدِكَ',
  ),
  TakhtaItem(
    title: 'دعائیں',
    subtitle: 'مسنون دعائیں',
    audioFile: 'dua.mp3',
    lessonText: 'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
  ),
];

// ─────────────────────────────────────────────
// Colors & Text Style helpers
// ─────────────────────────────────────────────
const kBg = Color(0xFF0A3D0A);
const kBgLight = Color(0xFF0D4A0D);
const kBgCard = Color(0xFF0F5A0F);
const kGold = Color(0xFFD4AF37);
const kGoldLight = Color(0xFFE8C84A);
const kWhite = Colors.white;

TextStyle urduStyle({
  double size = 18,
  Color color = kWhite,
  FontWeight weight = FontWeight.normal,
}) {
  return TextStyle(
    fontFamily: 'NotoNastaliqUrdu',
    fontSize: size,
    color: color,
    fontWeight: weight,
    height: 1.8,
  );
}

// ─────────────────────────────────────────────
// HOME SCREEN
// ─────────────────────────────────────────────
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _whatsappController = TextEditingController();

  @override
  void dispose() {
    _whatsappController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [kBgCard, kBg],
                ),
                border: const Border(
                  bottom: BorderSide(color: kGold, width: 2),
                ),
              ),
              child: Column(
                children: [
                  // Bismillah
                  Text(
                    'بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ',
                    textAlign: TextAlign.center,
                    textDirection: TextDirection.rtl,
                    style: urduStyle(size: 22, color: kGold, weight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  // Star decorations
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text('✦', style: TextStyle(color: kGold, fontSize: 14)),
                      const SizedBox(width: 8),
                      Text(
                        'قاعدہ نعمانیہ پشتو',
                        textAlign: TextAlign.center,
                        textDirection: TextDirection.rtl,
                        style: urduStyle(size: 32, color: kGold, weight: FontWeight.bold),
                      ),
                      const SizedBox(width: 8),
                      const Text('✦', style: TextStyle(color: kGold, fontSize: 14)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'مصنف: Babu Haider Haqqani',
                    textAlign: TextAlign.center,
                    style: urduStyle(size: 15, color: kGoldLight),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    width: 120,
                    height: 2,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.transparent, kGold, Colors.transparent],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // ── Takhta List ──
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: takhtaList.length,
                itemBuilder: (context, index) {
                  final item = takhtaList[index];
                  final isSpecial = index >= 31; // Namaz & Dua
                  return _TakhtaCard(
                    item: item,
                    index: index + 1,
                    isSpecial: isSpecial,
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => LessonScreen(item: item),
                        ),
                      );
                    },
                  );
                },
              ),
            ),

            // ── Footer ──
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                color: kBgCard,
                border: const Border(top: BorderSide(color: kGold, width: 1.5)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.chat, color: kGold, size: 20),
                  const SizedBox(width: 8),
                  Text(
                    'WhatsApp: ',
                    style: urduStyle(size: 14, color: kGoldLight),
                  ),
                  Expanded(
                    child: TextField(
                      controller: _whatsappController,
                      style: const TextStyle(color: kWhite, fontSize: 14),
                      decoration: const InputDecoration(
                        hintText: 'نمبر درج کریں',
                        hintStyle: TextStyle(color: Colors.white38, fontSize: 13),
                        isDense: true,
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TakhtaCard extends StatelessWidget {
  final TakhtaItem item;
  final int index;
  final bool isSpecial;
  final VoidCallback onTap;

  const _TakhtaCard({
    required this.item,
    required this.index,
    required this.isSpecial,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Material(
        color: isSpecial ? const Color(0xFF1A3A00) : kBgCard,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: isSpecial ? kGold : kGold.withOpacity(0.4),
                width: isSpecial ? 1.5 : 1,
              ),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              textDirection: TextDirection.rtl,
              children: [
                // Number badge
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: isSpecial ? kGold : kGold.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '$index',
                    style: TextStyle(
                      color: isSpecial ? kBg : kGold,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                // Text content
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        item.title,
                        textDirection: TextDirection.rtl,
                        style: urduStyle(
                          size: 18,
                          color: isSpecial ? kGold : kWhite,
                          weight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        item.subtitle,
                        textDirection: TextDirection.rtl,
                        style: urduStyle(size: 13, color: kGoldLight),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                // Play icon
                Icon(
                  Icons.play_circle_fill_rounded,
                  color: isSpecial ? kGold : kGold.withOpacity(0.7),
                  size: 30,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────
// LESSON SCREEN
// ─────────────────────────────────────────────
class LessonScreen extends StatefulWidget {
  final TakhtaItem item;

  const LessonScreen({super.key, required this.item});

  @override
  State<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends State<LessonScreen> {
  late AudioPlayer _audioPlayer;
  PlayerState _playerState = PlayerState.stopped;
  Duration _duration = Duration.zero;
  Duration _position = Duration.zero;
  bool _audioError = false;

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();

    _audioPlayer.onPlayerStateChanged.listen((state) {
      if (mounted) setState(() => _playerState = state);
    });

    _audioPlayer.onDurationChanged.listen((d) {
      if (mounted) setState(() => _duration = d);
    });

    _audioPlayer.onPositionChanged.listen((p) {
      if (mounted) setState(() => _position = p);
    });

    _audioPlayer.onPlayerComplete.listen((_) {
      if (mounted) {
        setState(() {
          _playerState = PlayerState.stopped;
          _position = Duration.zero;
        });
      }
    });
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  Future<void> _togglePlayPause() async {
    try {
      if (_playerState == PlayerState.playing) {
        await _audioPlayer.pause();
      } else if (_playerState == PlayerState.paused) {
        await _audioPlayer.resume();
      } else {
        setState(() => _audioError = false);
        await _audioPlayer.play(
          AssetSource('audio/${widget.item.audioFile}'),
        );
      }
    } catch (e) {
      setState(() => _audioError = true);
      debugPrint('Audio error: $e');
    }
  }

  Future<void> _stop() async {
    await _audioPlayer.stop();
    setState(() => _position = Duration.zero);
  }

  String _formatDuration(Duration d) {
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    final isPlaying = _playerState == PlayerState.playing;
    final isPaused = _playerState == PlayerState.paused;

    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top bar ──
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: const BoxDecoration(
                color: kBgCard,
                border: Border(bottom: BorderSide(color: kGold, width: 1.5)),
              ),
              child: Row(
                children: [
                  // Back button
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        border: Border.all(color: kGold),
                        borderRadius: BorderRadius.circular(8),
                        color: kGold.withOpacity(0.1),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.arrow_back_ios_new, color: kGold, size: 14),
                          const SizedBox(width: 4),
                          Text('واپس', style: urduStyle(size: 14, color: kGold)),
                        ],
                      ),
                    ),
                  ),
                  const Spacer(),
                  // Title
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        widget.item.title,
                        textDirection: TextDirection.rtl,
                        style: urduStyle(size: 18, color: kGold, weight: FontWeight.bold),
                      ),
                      Text(
                        widget.item.subtitle,
                        textDirection: TextDirection.rtl,
                        style: urduStyle(size: 12, color: kGoldLight),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // ── Main lesson area ──
            Expanded(
              child: Container(
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: kBgCard,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kGold.withOpacity(0.5), width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: kGold.withOpacity(0.05),
                      blurRadius: 20,
                      spreadRadius: 2,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // Decorative top
                    Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        border: Border(bottom: BorderSide(color: kGold.withOpacity(0.3))),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('❋', style: TextStyle(color: kGold.withOpacity(0.6), fontSize: 16)),
                          const SizedBox(width: 12),
                          Text(
                            'سبق',
                            style: urduStyle(size: 14, color: kGoldLight),
                          ),
                          const SizedBox(width: 12),
                          Text('❋', style: TextStyle(color: kGold.withOpacity(0.6), fontSize: 16)),
                        ],
                      ),
                    ),

                    // Lesson text
                    Expanded(
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: SingleChildScrollView(
                            child: Text(
                              widget.item.lessonText,
                              textAlign: TextAlign.center,
                              textDirection: TextDirection.rtl,
                              style: urduStyle(
                                size: 52,
                                color: kWhite,
                                weight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // ── Audio Player ──
            Container(
              margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: kBgCard,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: kGold.withOpacity(0.6), width: 1.5),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Audio file name
                  Text(
                    widget.item.audioFile,
                    style: TextStyle(
                      color: kGoldLight.withOpacity(0.7),
                      fontSize: 11,
                      letterSpacing: 1,
                    ),
                  ),
                  const SizedBox(height: 8),

                  // Error message
                  if (_audioError)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.red.withOpacity(0.4)),
                        ),
                        child: Text(
                          'آڈیو فائل نہیں ملی - فائل assets/audio/ میں رکھیں',
                          textDirection: TextDirection.rtl,
                          style: urduStyle(size: 12, color: Colors.red.shade300),
                        ),
                      ),
                    ),

                  // Progress bar
                  if (_duration > Duration.zero) ...[
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: kGold,
                        inactiveTrackColor: kGold.withOpacity(0.2),
                        thumbColor: kGold,
                        overlayColor: kGold.withOpacity(0.1),
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 8),
                        trackHeight: 4,
                      ),
                      child: Slider(
                        value: _position.inSeconds.toDouble().clamp(0, _duration.inSeconds.toDouble()),
                        min: 0,
                        max: _duration.inSeconds.toDouble(),
                        onChanged: (value) async {
                          await _audioPlayer.seek(Duration(seconds: value.toInt()));
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(_formatDuration(_position),
                              style: const TextStyle(color: Colors.white54, fontSize: 12)),
                          Text(_formatDuration(_duration),
                              style: const TextStyle(color: Colors.white54, fontSize: 12)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],

                  // Control buttons
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Stop button
                      _AudioButton(
                        icon: Icons.stop_rounded,
                        onTap: _stop,
                        size: 48,
                        iconSize: 24,
                        color: kGold.withOpacity(0.6),
                      ),
                      const SizedBox(width: 20),

                      // Play/Pause main button
                      GestureDetector(
                        onTap: _togglePlayPause,
                        child: Container(
                          width: 72,
                          height: 72,
                          decoration: BoxDecoration(
                            gradient: RadialGradient(
                              colors: [kGold, const Color(0xFFAA8C2A)],
                            ),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: kGold.withOpacity(0.4),
                                blurRadius: 16,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: Icon(
                            isPlaying
                                ? Icons.pause_rounded
                                : isPaused
                                    ? Icons.play_arrow_rounded
                                    : Icons.play_arrow_rounded,
                            color: kBg,
                            size: 40,
                          ),
                        ),
                      ),

                      const SizedBox(width: 20),

                      // Replay button
                      _AudioButton(
                        icon: Icons.replay_rounded,
                        onTap: () async {
                          await _audioPlayer.stop();
                          await Future.delayed(const Duration(milliseconds: 100));
                          await _togglePlayPause();
                        },
                        size: 48,
                        iconSize: 24,
                        color: kGold.withOpacity(0.6),
                      ),
                    ],
                  ),

                  const SizedBox(height: 8),

                  // Status text
                  Text(
                    isPlaying
                        ? 'چل رہا ہے...'
                        : isPaused
                            ? 'رکا ہوا ہے'
                            : 'چلانے کے لیے دبائیں',
                    textDirection: TextDirection.rtl,
                    style: urduStyle(size: 13, color: kGoldLight),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _AudioButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final double size;
  final double iconSize;
  final Color color;

  const _AudioButton({
    required this.icon,
    required this.onTap,
    required this.size,
    required this.iconSize,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          shape: BoxShape.circle,
          border: Border.all(color: color, width: 1.5),
        ),
        child: Icon(icon, color: color, size: iconSize),
      ),
    );
  }
}
